<?php

namespace App\Models;


use App\Traits\HistoryTrait;

class Subcategory extends BaseModel
{
    use HistoryTrait;
}
