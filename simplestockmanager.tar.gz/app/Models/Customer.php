<?php

namespace App\Models;


use App\Traits\HistoryTrait;

class Customer extends BaseModel
{
    use HistoryTrait;
}
