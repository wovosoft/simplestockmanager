<?php

namespace App\Models;


use App\Traits\HistoryTrait;

class PurchaseItem extends BaseModel
{
    use HistoryTrait;
}
