<?php

namespace App\Models;


use App\Traits\HistoryTrait;

class Purchase extends BaseModel
{
    use HistoryTrait;
}
