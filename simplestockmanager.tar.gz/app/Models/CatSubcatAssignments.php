<?php

namespace App\Models;


class CatSubcatAssignments extends BaseModel
{
    //
}
