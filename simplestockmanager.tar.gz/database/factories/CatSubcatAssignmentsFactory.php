<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\CatSubcatAssignments;
use Faker\Generator as Faker;

$factory->define(CatSubcatAssignments::class, function (Faker $faker) {
    return [
        //
    ];
});
