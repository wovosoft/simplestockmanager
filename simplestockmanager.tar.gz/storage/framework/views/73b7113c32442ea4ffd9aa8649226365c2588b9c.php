<?php $__env->startSection('pageTitle',$item->title); ?>
<?php $__env->startSection('seo'); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php
$answers = [];
?>

<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center" style="margin-top: 55px">
        <h1 class="text-center"><?php echo $item->title; ?></h1>
        <?php if($item->subject): ?>
            <div>Subject: <?php echo e($item->subject->title); ?></div>
        <?php endif; ?>
        <?php if($item->examination): ?>
            <div>Examination: <?php echo e($item->examination->title); ?></div>
        <?php endif; ?>
        <?php if($item->examTaker): ?>
            <div>Exam. Taker: <?php echo e($item->examTaker->department); ?></div>
        <?php endif; ?>
    </div>

    <div class="container mb-5" x-data="qData()">
        <div class="row mb-3">
            <div class="col">
                <div class="custom-control custom-switch d-inline-block">
                    <input class="custom-control-input" x-model="showAnswer" type="checkbox" id="show_answers"
                           autocomplete="off">
                    <label class="custom-control-label" for="show_answers">
                        Show Answers
                    </label>
                </div>
                <div class="custom-control custom-switch d-inline-block">
                    <input class="custom-control-input" x-model="showDescription" type="checkbox" id="showDescription"
                           autocomplete="off">
                    <label class="custom-control-label" for="showDescription">
                        Show Description
                    </label>
                </div>
                <div class="custom-control custom-switch d-inline-block">
                    <input class="custom-control-input" x-model="skillTest" type="checkbox" id="skillTest"
                           @change="enableTest()"
                           autocomplete="off">
                    <label class="custom-control-label" for="skillTest">
                        Skill Test
                    </label>
                </div>
            </div>
        </div>
        <div class="row mb-3" x-show="showDescription" style="display: none;">
            <div class="col">
                 <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, []); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <?php echo $item->description; ?>

                 <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>

         <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, ['footerClass' => 'text-center']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'card']); ?>
             <?php $__env->slot('header'); ?> 
                 <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                     <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '4']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['xs' => '12']); ?>
                        Date: <?php echo e(\Illuminate\Support\Carbon::parse($item->date)->format('d-m-Y')); ?> <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '4']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['xs' => '12','class' => 'text-md-center']); ?>Marks: <?php echo e($item->marks); ?> <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '4']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['xs' => '12','class' => 'text-md-right']); ?>Time: <?php echo e($item->duration); ?> <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php $__env->endSlot(); ?>
            <?php ($count=1); ?>
            <?php $__currentLoopData = $item->paper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <?php $__currentLoopData = $row->cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-<?php echo e(12/count($row->cols)); ?>">
                            <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($el->type==='question'): ?>
                                    <?php $__currentLoopData = $el->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($ans = []); ?>
                                        <h6><?php echo e($count++); ?>. <?php echo $question->title; ?></h6>
                                        <ul class="pl-3 list-style-none" id="q-<?php echo e($question->id); ?>">
                                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                if ($option->is_answer) {
                                                    $ans[] = $option->label;
                                                }
                                                ?>
                                                <li>
                                                    <span x-show="showAnswer" class="is-answer position-absolute"
                                                          style="left: 15px;">
                                                        <?php echo !!$option->is_answer?'&#10004;':null; ?>

                                                    </span>

                                                    <label>
                                                        <input x-show="skillTest" style="display: none;"
                                                               value="<?php echo e($option->label); ?>"
                                                               type="checkbox" class="answer-box">
                                                        <span x-bind:class="{'text-red':showAnswer}" <?php echo e($option->is_answer?'class=answer':''); ?>>
                                                            <?php echo e(join(" ) ",[$option->label,$option->answer])); ?>

                                                        </span>
                                                    </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <?php ($answers['q-'.$question->id]=$ans); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php $__env->slot('footer'); ?> 
                <button x-show="skillTest" @click="getResults()" type="button" style="min-width: 200px;"
                        class="btn btn-outline-dark">
                    Show Result
                </button>
                <button x-show="skillTest" @click="resetForm()" type="button" style="min-width: 200px;"
                        class="btn btn-outline-dark">
                    Reset
                </button>
             <?php $__env->endSlot(); ?>
         <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <template x-if="showResult">
             <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, ['title' => 'Result']); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                Correct Answers : <span x-text="correct_answers"></span><br>
                Wrong Answers : <span x-text="wrong_answers"></span><br>
                Total : <span x-text="total"></span><br>
                <div x-show="skillTest">
                    Time:
                    <span x-text="countUp.hour<10?('0'+countUp.hour):countUp.hour"></span>:
                    <span x-text="countUp.min<10?('0'+countUp.min):countUp.min"></span>:
                    <span x-text="countUp.second<10?('0'+countUp.second):countUp.second"></span>
                </div>
             <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </template>
        <div id="clock" x-show="skillTest">
            Time:
            <span x-text="countUp.hour<10?('0'+countUp.hour):countUp.hour"></span>:
            <span x-text="countUp.min<10?('0'+countUp.min):countUp.min"></span>:
            <span x-text="countUp.second<10?('0'+countUp.second):countUp.second"></span>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>

        function qData() {
            return {
                showAnswer: true,
                showDescription: false,
                skillTest: false,
                showResult: false,
                answers: <?php echo json_encode($answers, 15, 512) ?>,
                correct_answers: 0,
                wrong_answers: 0,
                total: 0,
                show_result: false,
                arrayMatch: function (arr1, arr2) {
                    if (arr1.length !== arr2.length) return false;
                    for (var i = 0; i < arr1.length; i++) {
                        if (arr1[i] !== arr2[i]) return false;
                    }
                    return true;
                },
                seconds: 0,
                countUp: {
                    hour: 0,
                    min: 0,
                    second: 0
                },
                theTimer: null,
                countUpTimer: function () {
                    if (this.theTimer) {
                        clearInterval(this.theTimer);
                        this.resetForm();
                    }
                    var the = this;
                    this.theTimer = setInterval(function () {
                        the.seconds++;
                        the.setTime();
                    }, 1000)
                },
                setTime: function () {
                    this.countUp.hour = parseInt(this.seconds / 3600) % 24;
                    this.countUp.min = parseInt(this.seconds / 60) % 60;
                    this.countUp.second = this.seconds % 60;
                },

                enableTest: function () {
                    this.showAnswer = false;
                    this.correct_answers = 0;
                    this.wrong_answers = 0;
                    this.total = 0;
                    this.showResult = false;
                    this.countUpTimer();
                },
                getResults: function () {
                    clearInterval(this.theTimer);
                    this.correct_answers = 0;
                    this.wrong_answers = 0;
                    this.showAnswer = true;
                    let total = 0;
                    for (var x in this.answers) {
                        total++;
                        var inputs = document.getElementById(x).querySelectorAll('.answer-box:checked');
                        var values = [];
                        for (var y = 0; y < inputs.length; y++) {
                            values.push(inputs[y].value);
                        }
                        if (this.arrayMatch(this.answers[x].sort(), values.sort())) {
                            this.correct_answers++;
                        } else {
                            this.wrong_answers++;
                        }
                    }
                    this.total = total;
                    this.showResult = true;
                },
                resetForm() {
                    this.seconds = 0;
                    this.setTime();
                    this.correct_answers = 0;
                    this.wrong_answers = 0;
                    this.total = 0;
                    this.showResult = false;
                    var boxes = document.querySelectorAll('.answer-box:checked');
                    for (var x = 0; x < boxes.length; x++) {
                        boxes[x].checked = false;
                    }
                }
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .list-style-none {
            list-style-type: none;
        }

        .is-answer {
            color: red;
        }

        .answer.text-red {
            color: red;
        }

        #clock {
            position: fixed;
            right: 30px;
            top: 20px;
            z-index: 9999;
            color: white;
        }

        @media  all and (max-width: 992px) {
            #clock {
                top: 60px;
                right: 3px;
                padding: 3px;
                color: red;
                background-color: rgba(0, 0, 0, 0.3);
                border-radius: 5px;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/question-paper-view.blade.php ENDPATH**/ ?>