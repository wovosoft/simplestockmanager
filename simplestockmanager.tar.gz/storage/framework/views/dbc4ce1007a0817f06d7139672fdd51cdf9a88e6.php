<div class="card mb-3" <?php echo e($attributes); ?>>
    <div class="card-header">
        Comments
    </div>
    <div class="card-body p-2">
        <?php $__currentLoopData = $comments->sortBy('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2">
                <div class="card-body">
                    <?php echo e($comment->content); ?>

                </div>
                <div class="card-footer">
                    <div class="row small">
                        <div class="col"><?php echo e($comment->user->name); ?></div>
                        <div class="col text-md-right">Commented
                            at <?php echo e(\Carbon\Carbon::parse($comment->created_at)->format('d-m-Y')); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if($comments->hasPages()): ?>
        <div class="card-footer">
            <div class="row">
                <div class="col-md-auto mb-0-pagination">
                    <?php echo e($comments->appends(['comments'=>request()->get('comments'),'questions'=>request()->get('questions')])->fragment('comments')->links()); ?>

                </div>
                <div class="col text-md-right">
                    Total : <?php echo e($comments->total()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<style>
    #comments::before {
        content: '';
        display: block;
        height: 75px;
        margin-top: -75px;
        visibility: hidden;
    }
</style>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/components/explanation-comments.blade.php ENDPATH**/ ?>