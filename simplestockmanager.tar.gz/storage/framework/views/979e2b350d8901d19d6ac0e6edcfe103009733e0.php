<img <?php echo e($attributes->merge($attrs)); ?>>
<?php /**PATH /home/narayan/Sites/questionbook/vendor/wovosoft/laravel-bootstrap/src/../resources/views/components/card-img.blade.php ENDPATH**/ ?>