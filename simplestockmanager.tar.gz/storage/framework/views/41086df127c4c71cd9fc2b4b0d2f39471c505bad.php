<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-2">
        <div class="card-header">
            <a href="<?php echo e(route('Questions.Explanations.View',$item->only('id','slug'))); ?>">
                <?php echo e(join(' # ',$item->only('id','title'))); ?>

            </a>
        </div>
        <div class="card-body">
            <?php echo $item->content; ?>

        </div>
        <div class="card-footer">
            <div class="row">
                <div class="col-md-6 small">
                    Created At <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d-m-Y')); ?>

                </div>
                <div class="col-md-6 small text-right">
                    Total Questions: <?php echo e($item->questions->count()); ?>

                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/components/explanations.blade.php ENDPATH**/ ?>