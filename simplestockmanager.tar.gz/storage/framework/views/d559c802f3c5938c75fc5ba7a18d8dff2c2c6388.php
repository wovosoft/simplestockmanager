<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WovoSoft Question Book</title>
    <base href="<?php echo e(url("/")); ?>">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(mix("css/app.css")); ?>">
    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
    <?php echo $__env->make('ckfinder::setup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script defer src="<?php echo e(mix('js/app-client.js')); ?>"></script>
</head>
<body class="h-100" style="overflow-x: hidden;">
<div id="app"></div>







<form id="logout-form" style="display: none" method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?></form>
</body>
</html>
<?php /**PATH /home/narayan/Sites/jarladr2/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>