<?php $__env->startSection('seo'); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron" style="margin-top: 50px;">
        <h1 class="text-center">Question Papers</h1>
    </div>
    <div class="container" x-data="{search: '<?php echo e($search); ?>',...<?php echo bInitData($url,$uid); ?> }">
        <div class="form-group">
            <label for="search_paper">Search Question Papers</label>
            <input id="search_paper" type="search" class="form-control"
                   x-model="search"
                   @input.debounce.100ms="wovo(url,'getUpdate',{search:search},{search:search,page:1},rid)"
                   placeholder="Type and Search Question Papers......">
        </div>
        <div :x-ref="rid">
             <?php if (isset($component)) { $__componentOriginal47b591db187988d4590b71184b96015cde3f3084 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\QuestionPapers::class, ['papers' => $papers]); ?>
<?php $component->withName('question-papers'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal47b591db187988d4590b71184b96015cde3f3084)): ?>
<?php $component = $__componentOriginal47b591db187988d4590b71184b96015cde3f3084; ?>
<?php unset($__componentOriginal47b591db187988d4590b71184b96015cde3f3084); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/jarladr2/resources/views/pages/question-papers.blade.php ENDPATH**/ ?>