<?php
$classList = [
    "card-footer"
];
if ($bgVariant) {
    $classList[] = "bg-$bgVariant";
}
if ($textVariant) {
    $classList[] = "text-$textVariant";
}
if ($borderVariant) {
    $classList[] = "border-$borderVariant";
}
?>

<<?php echo e($tag); ?> <?php echo e($attributes->merge(["class"=>join(" ",$classList)])); ?>>
<?php echo e($slot); ?>

</<?php echo e($tag); ?>>
<?php /**PATH /home/narayan/Sites/questionbook/vendor/wovosoft/laravel-bootstrap/src/../resources/views/components/card-footer.blade.php ENDPATH**/ ?>