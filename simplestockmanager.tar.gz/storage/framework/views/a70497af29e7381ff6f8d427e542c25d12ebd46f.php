<div class="card mt-3">
    <div class="card-header">
        Question Comments
    </div>
    <div class="card-body" id="comments">
         <?php if (isset($component)) { $__componentOriginal9aa7033e5075f5fad778d404adaa273d5e6f1771 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\QuestionCommentsView::class, ['question' => $question]); ?>
<?php $component->withName('question-comments-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9aa7033e5075f5fad778d404adaa273d5e6f1771)): ?>
<?php $component = $__componentOriginal9aa7033e5075f5fad778d404adaa273d5e6f1771; ?>
<?php unset($__componentOriginal9aa7033e5075f5fad778d404adaa273d5e6f1771); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
</div>
<?php if(auth()->guard()->check()): ?>
    <form method="post" x-on:submit.prevent="s"
          x-data="initialData()">
        <?php echo csrf_field(); ?>
        <div class="card mt-3">
            <div class="card-header">
                Comment
            </div>
            <div class="card-body p-1">
            <textarea class="form-control" :required="true" rows="5" x-model="comment"
                      name="comment" :minlength="6"
                      placeholder="Type Your Comment Here..."></textarea>
            </div>
            <div class="card-footer p-1">
                <button type="submit" class="btn btn-secondary btn-block">SUBMIT</button>
            </div>
        </div>
    </form>
<?php endif; ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function initialData() {
            return {
                comment: '',
                s: function () {
                    let the = this;
                    axios.post('<?php echo e(route('Questions.Forum')); ?>', {
                        method: 'addComment',
                        content: this.comment,
                        q: '<?php echo e(encrypt($question->id)); ?>',
                    }).then(function (res) {
                        document.getElementById('comments').innerHTML = res.data;
                        the.comment = '';
                    }).catch(function (err) {
                        console.log(err.response)
                    })
                }
            }
        }

    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/components/question-comments.blade.php ENDPATH**/ ?>