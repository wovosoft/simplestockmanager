<div <?php echo e($attributes->merge(["class"=> join(" ", $classList)])); ?>>
    <?php if($imgSrc): ?>
         <?php if (isset($component)) { $__componentOriginalae1d2355b862505052204ef759734f016ae13db5 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardImg::class, ['src' => $imgSrc,'alt' => $imgAlt,'top' => $imgTop,'bottom' => $imgBottom,'start' => $imgStart,'left' => $imgLeft,'end' => $imgEnd,'right' => $imgRight,'height' => $imgHeight,'width' => $imgWidth]); ?>
<?php $component->withName('card-img'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalae1d2355b862505052204ef759734f016ae13db5)): ?>
<?php $component = $__componentOriginalae1d2355b862505052204ef759734f016ae13db5; ?>
<?php unset($__componentOriginalae1d2355b862505052204ef759734f016ae13db5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>
    <?php if($header): ?>
         <?php if (isset($component)) { $__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardHeader::class, ['tag' => $headerTag,'bgVariant' => $headerBgVariant,'borderVariant' => $headerBorderVariant,'textVariant' => $headerTextVariant]); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($headerClass)]); ?>
            <?php echo e($header); ?>

         <?php if (isset($__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0)): ?>
<?php $component = $__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0; ?>
<?php unset($__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>
    <?php if(!$noBody): ?>
         <?php if (isset($component)) { $__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardBody::class, ['tag' => $bodyTag,'bgVariant' => $bodyBgVariant,'borderVariant' => $bodyBorderVariant,'textVariant' => $bodyTextVariant,'titleTag' => $titleTag,'titleClass' => $titleClass,'subTitleTag' => $subTitleTag,'subTitleTextVariant' => $subTitleTextVariant,'subTitleClass' => $subTitleClass]); ?>
<?php $component->withName('card-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($bodyClass)]); ?>
            <?php if($title): ?>
                 <?php $__env->slot('title'); ?> 
                    <?php echo e($title); ?>

                 <?php $__env->endSlot(); ?>
            <?php endif; ?>
            <?php if($subTitle): ?>
                 <?php $__env->slot('subTitle'); ?> 
                    <?php echo e($subTitle); ?>

                 <?php $__env->endSlot(); ?>
            <?php endif; ?>
            <?php echo e($slot); ?>

         <?php if (isset($__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88)): ?>
<?php $component = $__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88; ?>
<?php unset($__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php else: ?>
        <?php echo e($slot); ?>

    <?php endif; ?>
    <?php if($footer): ?>
         <?php if (isset($component)) { $__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardFooter::class, ['bgVariant' => $footerBgVariant,'textVariant' => $footerTextVariant,'borderVariant' => $footerBorderVariant,'tag' => $footerTag]); ?>
<?php $component->withName('card-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($footerClass)]); ?>
            <?php echo e($footer); ?>

         <?php if (isset($__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e)): ?>
<?php $component = $__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e; ?>
<?php unset($__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>
</div>
<?php /**PATH /home/narayan/Sites/questionbook/vendor/wovosoft/laravel-bootstrap/src/../resources/views/components/card.blade.php ENDPATH**/ ?>