<?php $__env->startSection("seo"); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function showVideo(e) {
            e.preventDefault();
        }
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center" style="margin-top: 55px;">
        <h1><?php echo e($item->title); ?></h1>
        <h4 class="text-secondary">By <?php echo e($item->author); ?></h4>
        <p>
            <small class="text-muted">
                <?php echo e(\Carbon\Carbon::parse($item->updated)->diffForHumans()); ?>

            </small>
            <small class="text-muted mx-4">
                Total <?php echo e($item->chapters->count()); ?> Chapters
            </small>
            <small class="text-muted">
                Enrolled <?php echo e(random_int(1,1000)); ?>

            </small>
        </p>
        <div>
             <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, ['variant' => 'dark']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Enroll Now <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, ['variant' => 'primary']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>Contact Us <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
     <?php if (isset($component)) { $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Container::class, []); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-5','x-data' => '{modal:false,video_url:null,title:\'\'}']); ?>
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <?php if($item->thumbnail): ?>
                 <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '4']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <a href="<?php echo e(route('Courses.View',$item->only('id','slug'))); ?>">
                        <img src="<?php echo e($item->thumbnail); ?>" class="card-img" alt="<?php echo e($item->title); ?>">
                    </a>
                 <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, []); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'col-xs-auto']); ?>
                <h2>Overview</h2>
                <?php echo $item->overview; ?>

             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '6']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <h2 class="mt-5">Requirements</h2>
                <?php echo $item->requirements; ?>

             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '6']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <h2 class="mt-5">Objectives</h2>
                <?php echo $item->objectives; ?>

             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <h2 class="mt-5">Chapters</h2>
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'row-eq-height']); ?>
            <?php $__currentLoopData = $item->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '4','sm' => '6']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['xs' => '12','class' => 'mb-3']); ?>
                     <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, ['noBody' => true]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-3 h-100']); ?>
                        <a href="https://www.youtube.com/embed/nKfs85QIFqY"
                           @click.stop.prevent="modal=true,video_url='<?php echo e($chapter->video_url); ?>',title='<?php echo e($chapter->title); ?>'">
                             <?php if (isset($component)) { $__componentOriginalae1d2355b862505052204ef759734f016ae13db5 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardImg::class, ['src' => $chapter->thumbnail]); ?>
<?php $component->withName('card-img'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalae1d2355b862505052204ef759734f016ae13db5)): ?>
<?php $component = $__componentOriginalae1d2355b862505052204ef759734f016ae13db5; ?>
<?php unset($__componentOriginalae1d2355b862505052204ef759734f016ae13db5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </a>
                         <?php if (isset($component)) { $__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardHeader::class, []); ?>
<?php $component->withName('card-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <a href="<?php echo e(route('Courses.Chapter.View',array_merge($chapter->only('id','slug'),["course_slug"=>$item->slug]))); ?>">
                                <?php echo e(join(' # ',[$chapter->order??$chapter->id,$chapter->title])); ?>

                            </a>
                         <?php if (isset($__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0)): ?>
<?php $component = $__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0; ?>
<?php unset($__componentOriginal811aec064f6a0191692fa8ae30860bad965271a0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardBody::class, []); ?>
<?php $component->withName('card-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                             <?php if (isset($component)) { $__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardText::class, []); ?>
<?php $component->withName('card-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                <?php echo $chapter->overview; ?>

                             <?php if (isset($__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986)): ?>
<?php $component = $__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986; ?>
<?php unset($__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88)): ?>
<?php $component = $__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88; ?>
<?php unset($__componentOriginalf294fb9e063f59383c28023a83ebe416876bde88); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardFooter::class, []); ?>
<?php $component->withName('card-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'small text-muted']); ?>
                            Last updated at <?php echo e(Carbon\Carbon::parse($chapter->created_at)->diffForHumans()); ?>

                         <?php if (isset($__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e)): ?>
<?php $component = $__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e; ?>
<?php unset($__componentOriginalc1f5eaefaf77c6a34aa16b74e9922301edbeb33e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <div class="modal fade" :class="{show:modal}" x-show="modal" role="dialog"
             style="background: rgba(0, 0, 0, 0.5)">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <div class="modal-title" x-text="title"></div>
                         <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, []); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'close text-white','@click' => 'modal=false','data-dismiss' => 'modal','aria-label' => 'Close']); ?>
                            <span aria-hidden="true">&times;</span>
                         <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                    <div class="modal-body p-0">
                        <template x-if="video_url">
                            <div class="embed-responsive embed-responsive-16by9">
                                <iframe class="embed-responsive-item" :src="video_url" frameborder="0"
                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                        allowfullscreen></iframe>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>
     <?php if (isset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c)): ?>
<?php $component = $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c; ?>
<?php unset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <style>
        .modal.show {
            display: block;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/courses/view.blade.php ENDPATH**/ ?>