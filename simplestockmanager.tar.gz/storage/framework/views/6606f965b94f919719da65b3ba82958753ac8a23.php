<?php $__env->startSection('pageTitle',$question->title); ?>
<?php $__env->startSection('seo'); ?>
    <meta name="description" content="<?php echo e($question->description); ?>">
    <meta name="keywords"
          content="<?php echo e($question->categories->pluck('name')->join(', ')); ?>,<?php echo e($question->tags->pluck('name')->join(', ')); ?>">
<?php $__env->stopSection(); ?>
<div class="container" style="margin-top: 80px;">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <?php echo e(join(' # ',[$question->id,$question->title])); ?>

                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <?php echo e(join(' ',[$option->label,' ) ',$option->answer])); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if($question->description): ?>
                        <hr>
                        <div class="row" id="description">
                            <div class="col-md-12">
                                <fieldset>
                                    <legend>
                                        <a href="#description">Description</a>
                                    </legend>
                                    <?php echo $question->description; ?>

                                </fieldset>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col">
                            Answers :
                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(in_array($option->id,$question->answers->pluck('option_id')->toArray())): ?>
                                    <?php echo e(join(' ',[$option->label,' ) ',$option->answer])); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col text-right">
                            <small><?php echo e($question->created_at); ?></small>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($question->explanations && $question->explanations->count()): ?>
                <div class="card mt-3" id="explanations">
                    <div class="card-header">
                        <a href="#explanations">Explanations</a>
                    </div>
                    <div class="card-body">
                        <ol class="m-0 px-3">
                            <?php $__currentLoopData = $question->explanations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $explanation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <p><?php echo $explanation->content; ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card mt-3" id="meta_information">
                <div class="card-header">
                    <a href="#meta_information">Meta Information</a>
                </div>
                <div class="card-body p-0">
                    <table class="table table-hover">
                        <tbody>

                        <?php if($question->categories->count()): ?>
                            <tr>
                                <td>Categories</td>
                                <td><?php echo e($question->categories->pluck('name')->join(', ')); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($question->tags->count()): ?>
                            <tr>
                                <td>Tags</td>
                                <td><?php echo e($question->tags->pluck('name')->join(', ')); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($question->subjects->count()): ?>
                            <tr>
                                <td>Subjects</td>
                                <td><?php echo e($question->subjects->pluck('title')->join(', ')); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($question->books->count()): ?>
                            <tr>
                                <td>Books</td>
                                <td><?php echo e($question->books->pluck('title')->join(', ')); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if($question->examinations->count()): ?>
                            <tr>
                                <td>Examinations</td>
                                <td><?php echo e($question->examinations->pluck('title')->join(', ')); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>


                </div>
            </div>
            <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('question-comments', ['question' => $question])->dom;
} elseif ($_instance->childHasBeenRendered('z5VTru5')) {
    $componentId = $_instance->getRenderedChildComponentId('z5VTru5');
    $componentTag = $_instance->getRenderedChildComponentTagName('z5VTru5');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('z5VTru5');
} else {
    $response = \Livewire\Livewire::mount('question-comments', ['question' => $question]);
    $dom = $response->dom;
    $_instance->logRenderedChild('z5VTru5', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

            <?php
                $next= $question->next();
                $previous=$question->previous();
            ?>
            <div class="text-center mt-3">
                <?php if($next): ?>
                    <a class="btn btn-outline-dark" href="<?php echo e(route('Questions.View',$next->slug)); ?>"
                       title="<?php echo e($next->title); ?>">Previous</a>
                <?php endif; ?>
                <?php if($previous): ?>
                    <a class="btn btn-outline-dark" href="<?php echo e(route('Questions.View',$previous->slug)); ?>"
                       title="<?php echo e($previous->title); ?>">Next</a>
                <?php endif; ?>
            </div>
            <?php if($question->references && $question->references->count()): ?>
                <fieldset class="mt-5" id="references">
                    <legend>
                        <a href="#references">References</a>
                    </legend>
                    <ol>
                        <?php $__currentLoopData = $question->references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php echo e($reference->title); ?>

                                <a title="<?php echo e($reference->title); ?>" target="_blank" href="<?php echo e($reference->url); ?>">
                                    <?php echo e($reference->url); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </fieldset>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/livewire/question-view.blade.php ENDPATH**/ ?>