<<?php echo e($tag); ?> <?php echo e($attributes->merge($attrs)); ?>>
<?php if($shouldWrap): ?>
     <?php if (isset($component)) { $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Container::class, ['fluid' => $containerFluid]); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($containerClass)]); ?>
        <?php echo $__env->make('components.jumbotron-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php if (isset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c)): ?>
<?php $component = $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c; ?>
<?php unset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php else: ?>
    <?php echo $__env->make('components.jumbotron-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
</<?php echo e($tag); ?>>
<?php /**PATH /home/narayan/Sites/questionbook/vendor/wovosoft/laravel-bootstrap/src/../resources/views/components/jumbotron.blade.php ENDPATH**/ ?>