<?php $__env->startSection("seo"); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="jumbotron text-center" style="margin-top: 55px;">
        <h3><?php echo e($item->title); ?></h3>
        <p class="text-muted small">
            Last Updated <?php echo e(\Carbon\Carbon::parse($item->updated)->diffForHumans()); ?>

        </p>
    </div>
     <?php if (isset($component)) { $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Container::class, []); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-5']); ?>
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, []); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                 <?php if (isset($component)) { $__componentOriginal71dc722abda84ccd49952fe43e6d7b575685caf6 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Embed::class, []); ?>
<?php $component->withName('embed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['src' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->video_url),'allowfullscreen' => true]); ?> <?php if (isset($__componentOriginal71dc722abda84ccd49952fe43e6d7b575685caf6)): ?>
<?php $component = $__componentOriginal71dc722abda84ccd49952fe43e6d7b575685caf6; ?>
<?php unset($__componentOriginal71dc722abda84ccd49952fe43e6d7b575685caf6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '9']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                 <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, []); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'chapter-content']); ?>
                     <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-3']); ?>
                        <?php if($item->previous): ?>
                             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, []); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                 <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, ['href' => route('Courses.Chapter.View',array_merge($item->previous->only('id','slug'),['course_slug'=>$item->course->slug])),'size' => 'sm','variant' => 'outline-primary']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                    Previous
                                 <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endif; ?>
                        <?php if($item->next): ?>
                             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, []); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-md-right']); ?>
                                 <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, ['href' => route('Courses.Chapter.View',array_merge($item->next->only('id','slug'),['course_slug'=>$item->course->slug])),'size' => 'sm','variant' => 'outline-primary']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                    Next
                                 <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endif; ?>
                     <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php if($item->requirements): ?>
                        <h2>Requirements</h2>
                        <div class="mb-3">
                            <?php echo $item->requirements; ?>

                        </div>
                    <?php endif; ?>

                    <?php if($item->objectives): ?>
                        <h2>What You will learn...</h2>
                        <div class="mb-3">
                            <?php echo $item->objectives; ?>

                        </div>
                    <?php endif; ?>


                    <?php echo $item->description; ?>


                    <?php if($item->previous || $item->next): ?>
                         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-3']); ?>
                            <?php if($item->previous): ?>
                                 <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, []); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                     <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, ['href' => route('Courses.Chapter.View',array_merge($item->previous->only('id','slug'),['course_slug'=>$item->course->slug])),'size' => 'sm','variant' => 'outline-primary']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                        Previous
                                     <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endif; ?>
                            <?php if($item->next): ?>
                                 <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, []); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-md-right']); ?>
                                     <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, ['href' => route('Courses.Chapter.View',array_merge($item->next->only('id','slug'),['course_slug'=>$item->course->slug])),'size' => 'sm','variant' => 'outline-primary']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                        Next
                                     <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endif; ?>
                         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php endif; ?>
                 <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '3']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div style="overflow: auto;" id="video-list">
                    <?php $__currentLoopData = $item->course->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($component)) { $__componentOriginal8d91b96e597b64761f624bc63da6c704439ba130 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Link::class, ['active' => $chapter->id==$item->id,'href' => route('Courses.Chapter.View',array_merge($chapter->only('id','slug'),['course_slug'=>$item->slug]))]); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chapter->title)]); ?>
                             <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, ['imgSrc' => $chapter->thumbnail]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-3']); ?>
                                <?php echo e(join(' # ',[$chapter->order??$chapter->id,$chapter->title])); ?>

                             <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($__componentOriginal8d91b96e597b64761f624bc63da6c704439ba130)): ?>
<?php $component = $__componentOriginal8d91b96e597b64761f624bc63da6c704439ba130; ?>
<?php unset($__componentOriginal8d91b96e597b64761f624bc63da6c704439ba130); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c)): ?>
<?php $component = $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c; ?>
<?php unset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        window.addEventListener('resize', setChapterListHeight);
        window.addEventListener("load", setChapterListHeight);

        function setChapterListHeight() {
            if (window.outerWidth >= 768) {
                document.getElementById("video-list").style.maxHeight = document.getElementById("chapter-content").clientHeight + "px";
            } else {
                document.getElementById("video-list").style.maxHeight = "auto";
            }
        }
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.frontend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/courses/chapter.blade.php ENDPATH**/ ?>