<div class="jumbotron" style="margin-top: 50px;">
    <h1 class="text-center">Question Papers</h1>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php $__currentLoopData = $papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3">
                    <div class="card-header text-center">
                        <a href=" <?php echo e(route('Questions.Papers.View',$paper->slug)); ?>"> <?php echo e($paper->title); ?></a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                Marks: <?php echo e($paper->marks); ?>

                            </div>
                            <div class="col">
                                Date: <?php echo e($paper->date); ?>

                            </div>
                            <div class="col">
                                Duration: <?php echo e($paper->duration); ?> hours
                            </div>
                        </div>
                        <hr>
                        <p><?php echo $paper->description; ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($papers->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/livewire/question-papers.blade.php ENDPATH**/ ?>