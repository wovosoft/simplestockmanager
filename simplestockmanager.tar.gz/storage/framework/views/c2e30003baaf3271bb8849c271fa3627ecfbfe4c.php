<div <?php echo e($attributes->merge($attrs)); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH /home/narayan/Sites/questionbook/storage/framework/views/9b5687ce43424776841c7ee16d7ce72ac566f04e.blade.php ENDPATH**/ ?>