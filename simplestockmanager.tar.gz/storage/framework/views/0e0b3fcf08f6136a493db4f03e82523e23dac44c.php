<div style="margin-top: 100px">
   <input type="text" wire:model="name">
    <?php echo e($name); ?> <?php echo e($hi); ?>

</div>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/livewire/test.blade.php ENDPATH**/ ?>