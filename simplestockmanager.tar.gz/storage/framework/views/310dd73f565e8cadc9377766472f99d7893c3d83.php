<nav x-data="{isOpen:false}" class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top"
     style="background-color: #1a4675 !important;">
    <div class="container">
        <a class="navbar-brand font-italic font-weight-bold"
           style="letter-spacing: 2px"
           title="Wovo Solution | Jack of all trades, master of none" href="<?php echo e(route('Home')); ?>">
            <?php echo e(env('APP_NAME')); ?>

        </a>
        <button @click="isOpen=!isOpen" class="navbar-toggler" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" :aria-expanded="isOpen" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" :class="{show:isOpen}" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(isActiveRoute('Questions.Papers')); ?>"
                       href="<?php echo e(route('Questions.Papers')); ?>">Question Papers</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(isActiveRoute('Questions.Forum')); ?>"
                       href="<?php echo e(route('Questions.Forum')); ?>">Forum</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(isActiveRoute('Job.Circulars')); ?>" title="Job Circulars"
                       href="<?php echo e(route('Job.Circulars')); ?>">Job Circulars</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(isActiveRoute('Courses')); ?>" title="Courses"
                       href="<?php echo e(route('Courses')); ?>">Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(isActiveRoute('Blog.Posts')); ?>" title="Blog Posts"
                       href="<?php echo e(route('Blog.Posts')); ?>">
                        Blog
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(isActiveRoute('About')); ?>" title="About Us" href="<?php echo e(route('About')); ?>">
                        About
                    </a>
                </li>
            </ul>
            
            
            
            
            
            
            
            
            
            
            
            <ul class="navbar-nav mr-auto" x-data="{ps:false}">
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown" :class="{'show':ps}">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                           @click.stop.prevent="ps=!ps" @click.away="ps=false"
                           data-toggle="dropdown" aria-haspopup="true" :aria-expanded="ps">
                            <?php echo e(auth()->user()->name); ?>

                        </a>
                        <div class="dropdown-menu" :class="{'show':ps}" aria-labelledby="navbarDropdown">
                            <?php if(auth()->user()->can('has dashboard access')): ?>
                                <a class="dropdown-item" style="cursor: pointer;" href="<?php echo e(route('Admin')); ?>">Admin</a>
                            <?php endif; ?>
                            <a class="dropdown-item" style="cursor: pointer;"
                               onclick="document.getElementById('logout-form').submit()">Logout</a>
                        </div>
                    </li>

                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer;" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer;" href="<?php echo e(route('register')); ?>">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<form id="logout-form" style="display: none" method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?></form>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>