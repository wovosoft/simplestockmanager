<?php $__env->startSection('seo'); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron" style="margin-top: 55px;">
        <div class="container">
            <h1 class="text-center"><?php echo e($question->title); ?></h1>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                 <?php if (isset($component)) { $__componentOriginal0977c08af8b3bf61eca29354516f60c13b84c8fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\QuestionView::class, ['question' => $question]); ?>
<?php $component->withName('question-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal0977c08af8b3bf61eca29354516f60c13b84c8fd)): ?>
<?php $component = $__componentOriginal0977c08af8b3bf61eca29354516f60c13b84c8fd; ?>
<?php unset($__componentOriginal0977c08af8b3bf61eca29354516f60c13b84c8fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/question-view.blade.php ENDPATH**/ ?>