<?php $__env->startSection('seo'); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center" style="margin-top: 55px;">
        <h1>Available Courses</h1>
    </div>
     <?php if (isset($component)) { $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Container::class, []); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'row-eq-height']); ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '6','sm' => '12']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-3']); ?>
                    <div class="card h-100">
                        <div class="row no-gutters">
                            <div class="col-md-4">
                                <a href="<?php echo e(route('Courses.View',$item->only('id','slug'))); ?>">
                                    <img src="<?php echo e($item->thumbnail); ?>" class="card-img h-100" alt="<?php echo e($item->title); ?>">
                                </a>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body p-3">
                                    <a class="text-decoration-none text-dark"
                                       href="<?php echo e(route('Courses.View',$item->only('id','slug'))); ?>">
                                        <h5 class="card-title" title="<?php echo e($item->title); ?>">
                                            <?php echo e(\Illuminate\Support\Str::substr($item->title,0,30)); ?>...
                                        </h5>
                                    </a>
                                    <small class="text-muted">By <?php echo e($item->author); ?></small>
                                    <p class="card-text">
                                        <?php echo e(\Illuminate\Support\Str::substr(strip_tags($item->description),0,100)); ?>...
                                    </p>
                                    <p class="card-text row">
                                        <small class="text-muted col-4"> <?php echo e($item->chapters_count); ?> Chapters</small>
                                        <small class="text-muted col text-right">
                                            Last updated <?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?>

                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                 <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['cass' => 'mb-5']); ?>
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '6','sm' => '12']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php echo e($items->links()); ?>

             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '6','sm' => '12']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-md-right']); ?>
                Total <?php echo e($items->count()); ?>

             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c)): ?>
<?php $component = $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c; ?>
<?php unset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/courses/list.blade.php ENDPATH**/ ?>