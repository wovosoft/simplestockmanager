<div class="container" style="margin-top: 80px">
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>Search Question</label>
                <input placeholder="Type here to find your desired answer..." class="form-control" wire:model="name">
            </div>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-2">
                    <div class="card-header">
                        <?php echo e((($questions->currentPage()-1) * $questions->perPage() + $index+1)); ?>.
                        <a href="<?php echo e(route('Questions.View',$question->slug)); ?>"><?php echo e($question->title); ?></a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <?php echo e(join(' ',[$option->label,' ) ',$option->answer])); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col">
                                Answers :
                                <?php
                                    foreach($question->options as $option):
                                            if(in_array($option->id,$question->answers->pluck('option_id')->toArray())):
                                                 echo join(' ',[$option->label,' ) ',$option->answer]);
                                            endif;
                                    endforeach;
                                ?>
                            </div>
                            <div class="col text-right">
                                <small><?php echo e($question->created_at); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="row">
                <div class="col-md-3">
                    Total Items: <?php echo e($questions->total()); ?>

                </div>
                <div class="col"><?php echo e($questions->links()); ?></div>
            </div>
        </div>
    </div>
</div>
<style>
    .cc > .pagination {
        justify-content: center;
    }
</style>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/livewire/forum.blade.php ENDPATH**/ ?>