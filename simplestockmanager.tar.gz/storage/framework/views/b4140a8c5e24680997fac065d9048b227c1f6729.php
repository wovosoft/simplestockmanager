<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($comment->content); ?></p>
    <div class="text-right small font-italic">
        -- <?php echo e($comment->user->name); ?>

        , <?php echo e(\Carbon\Carbon::parse($comment->created_at)->format('d-m-Y \a\t h:i:s A')); ?>

    </div>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="cc"><?php echo e($comments->links()); ?></div>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/components/question-comments-view.blade.php ENDPATH**/ ?>