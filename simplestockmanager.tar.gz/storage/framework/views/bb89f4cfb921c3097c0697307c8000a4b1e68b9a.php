<?php $__env->startSection('seo'); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron" style="margin-top: 55px;">
        <h1 class="text-center">Job Circulars</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col">
                 <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, []); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-3']); ?>
                     <?php $__env->slot('header'); ?> 
                        <a href="<?php echo e(route('Job.Circulars.View',$item->only('id','slug'))); ?>"><?php echo e($item->title); ?></a>
                     <?php $__env->endSlot(); ?>
                    <?php echo $item->content; ?>

                     <?php $__env->slot('footer'); ?> 
                        <div class="row small">
                            <div class="col">
                                <strong>Published At:</strong>
                                <?php echo e(\Carbon\Carbon::parse($item->publication_date)->toDayDateTimeString()); ?>

                            </div>
                            <div class="row text-md-right">
                                <strong> Validity : </strong>
                                From <?php echo e(\Carbon\Carbon::parse($item->publication_date)->toDayDateTimeString()); ?>

                                to <?php echo e(\Carbon\Carbon::parse($item->expiration_date)->toDayDateTimeString()); ?>

                            </div>
                        </div>
                     <?php $__env->endSlot(); ?>
                 <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <?php if($item->application_url): ?>
                     <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, []); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-5 text-center']); ?>
                         <?php if (isset($component)) { $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Button::class, ['target' => '_blank','href' => $item->application_url]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->title)]); ?>Apply Now
                         <?php if (isset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc)): ?>
<?php $component = $__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc; ?>
<?php unset($__componentOriginal5138450472df07fc9033b92a49a9c2c0e1f2afbc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/job-circulars-view.blade.php ENDPATH**/ ?>