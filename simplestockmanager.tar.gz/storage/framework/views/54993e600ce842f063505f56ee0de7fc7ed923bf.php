<?php $__env->startSection('content'); ?>
    <h1 class="mt-navbar">Hello This is section</h1>
    <?php echo e(var_dump($with)); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/categories.blade.php ENDPATH**/ ?>