<div {{$attributes->merge($attrs)}}>
    {{$slot}}
</div>