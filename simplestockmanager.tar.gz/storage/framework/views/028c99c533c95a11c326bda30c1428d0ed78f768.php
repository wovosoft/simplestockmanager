<div>
    <form wire:submit.prevent="submitComment(Object.fromEntries(new FormData($event.target)))">
        <div class="card mt-3">
            <div class="card-header">
                Comments
            </div>
            <div class="card-body p-2">
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($comment->content); ?></p>
                    <div class="text-right small font-italic">
                        -- <?php echo e($comment->user->name); ?>

                        , <?php echo e(\Carbon\Carbon::parse($comment->created_at)->format('d-m-Y \a\t h:i:s A')); ?>

                    </div>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="cc"><?php echo e($comments->links()); ?></div>
                <div class="form-group">
                    <textarea rows="5" class="form-control"
                              placeholder="Your Comment Here..."
                              wire:model="content"
                              required></textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="card-footer text-center">
                <button type="submit" style="min-width: 200px" class="btn btn-dark">SUBMIT</button>
            </div>
        </div>
    </form>
</div>
<style>
    .cc > .pagination {
        justify-content: center;
    }
</style>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/livewire/question-comments.blade.php ENDPATH**/ ?>