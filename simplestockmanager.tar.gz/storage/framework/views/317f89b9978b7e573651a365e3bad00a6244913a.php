<?php
$questions = $item->questions()->paginate(20, ['*'], 'questions');
$comments = $item->comments()->latest()->paginate(5, ['*'], 'comments');
?>
<div class="card mb-3">
    <div class="card-header">
        <?php echo e($item->title); ?>

    </div>
    <div class="card-body">
        <?php echo $item->content; ?>

    </div>
    <div class="card-footer">
        <div class="row">
            <div class="col-md-6 small">
                Created At <?php echo e(Carbon\Carbon::parse($item->created_at)->format('d-m-Y')); ?>

            </div>
            <div class="col-md-6 text-right small">
                Total Questions : <?php echo e($questions->total()); ?>

            </div>
        </div>
    </div>
</div>
<div class="card mb-3">
    <div class="card-header">
        Related Questions
    </div>
    <div class="card-body row">
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                 <?php if (isset($component)) { $__componentOriginalaaf3a30ff2495783eba07ba1c1d62cc686ee37d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\QuestionBlock::class, ['question' => $question]); ?>
<?php $component->withName('question-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalaaf3a30ff2495783eba07ba1c1d62cc686ee37d7)): ?>
<?php $component = $__componentOriginalaaf3a30ff2495783eba07ba1c1d62cc686ee37d7; ?>
<?php unset($__componentOriginalaaf3a30ff2495783eba07ba1c1d62cc686ee37d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="card-footer mb-0-paginator">
        <div class="row">
            <div class="col-md-auto">
                <?php echo e($questions->hasPages() ? $questions->appends(['comments'=>request()->get('comments'),'questions'=>request()->get('questions')])->links() : 'No more pages...'); ?>

            </div>
            <div class="col text-right">
                Total : <?php echo e($questions->total()); ?>

            </div>
        </div>
    </div>
</div>
<div x-ref="comments" id="comments">
     <?php if (isset($component)) { $__componentOriginalad3c2cddc598debde8168f4c57351101babd1ff4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ExplanationComments::class, ['comments' => $comments]); ?>
<?php $component->withName('explanation-comments'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalad3c2cddc598debde8168f4c57351101babd1ff4)): ?>
<?php $component = $__componentOriginalad3c2cddc598debde8168f4c57351101babd1ff4; ?>
<?php unset($__componentOriginalad3c2cddc598debde8168f4c57351101babd1ff4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>

<form class="mb-3 card" x-data="{content:'',eid:'<?php echo e(encrypt($item->id)); ?>'}"
      @submit.prevent="wovo('<?php echo e(route('Questions.Explanations.View',$item->only('id','slug'))); ?>','addComment',{eid:eid,content:content},null,'comments',function(){content=''})">
    <div class="card-header">
        <label for="comment">Your Comment</label>
    </div>
    <div class="card-body p-2">
        <textarea id="comment" x-model="content"
                  placeholder="Write Your Comment here..."
                  :required="true"
                  class="form-control"
                  rows="5"></textarea>
    </div>
    <div class="card-footer p-2">
        <button type="submit" class="btn btn-dark btn-block mt-2">SUBMIT</button>
    </div>
</form>

<style>
    .mb-0-paginator .pagination {
        margin-bottom: 0 !important;
    }
</style>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/components/explanation-view.blade.php ENDPATH**/ ?>