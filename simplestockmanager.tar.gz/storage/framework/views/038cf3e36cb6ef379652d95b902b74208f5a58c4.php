<?php $__env->startSection('pageTitle',$item->title); ?>
<?php $__env->startSection('seo'); ?>
    <meta name="description" content="<?php echo e($item->description); ?>">
<?php $__env->stopSection(); ?>

<div class="jumbotron" style="margin-top: 55px">
    <h1 class="text-center"><?php echo e($item->title); ?></h1>
    <div class="container mt-3">
        <div class="row">
            <div class="col-md-12 text-center">
                <?php echo e($item->description); ?>

            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col text-center">
                            Date: <?php echo e(\Illuminate\Support\Carbon::parse($item->date)->format('d-m-Y')); ?></div>
                        <div class="col text-center">Marks: <?php echo e($item->marks); ?></div>
                        <div class="col text-center">Time: <?php echo e($item->duration); ?></div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php ($index = 0); ?>
                        <?php $__currentLoopData = $item->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $aa = [];
                            ?>
                            <div class="col-md-6 mb-5">
                                <h5>
                                    <a href="<?php echo e(route('Questions.View',$question->slug)); ?>">
                                        <?php echo e(join(' # ',[++$index,$question->title])); ?>

                                    </a>
                                </h5>
                                <ul style="list-style-type: none;" class="m-0 p-0">
                                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($option->label); ?>) <?php echo e($option->answer); ?></li>
                                        <?php
                                        if ($option->is_answer) {
                                            $aa[] = join(') ', [$option->label, $option->answer]);
                                        }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <div class="mt-2">
                                    Answer: <?php echo e(join(", ",$aa)); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH /home/narayan/Sites/questionbook/resources/views/livewire/question-paper-view.blade.php ENDPATH**/ ?>