<{{$tag}} {{$attributes->merge(["class"=>join(" ",$classList)])}}>
@if($title)<x-card-title :tag="$titleTag" :class="$titleClass">{{$title}}</x-card-title>@endif
@if($subTitle)<x-card-sub-title :text-variant="$subTitleTextVariant" :tag="$subTitleTag" :class="$titleClass">{{$subTitle}}</x-card-sub-title>@endif
{{$slot}}
</{{$tag}}>