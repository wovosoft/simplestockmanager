<?php if($button): ?>
    <div <?php echo e($attributes->merge($attrs)); ?>>
        <label <?php echo $attributesResolve('labelAttrs'); ?>>
            <input <?php echo $attributesResolve('inputAttrs'); ?>>
            <?php echo e($slot); ?>

        </label>
    </div>
<?php else: ?>
    <div <?php echo e($attributes->merge($attrs)); ?>>
        <input <?php echo $attributesResolve('inputAttrs'); ?>>
        <label <?php echo $attributesResolve('labelAttrs'); ?>>
            <?php echo e($slot); ?>

        </label>
    </div>
<?php endif; ?>
<?php /**PATH /home/narayan/Sites/questionbook/vendor/wovosoft/laravel-bootstrap/src/../resources/views/components/form-checkbox.blade.php ENDPATH**/ ?>