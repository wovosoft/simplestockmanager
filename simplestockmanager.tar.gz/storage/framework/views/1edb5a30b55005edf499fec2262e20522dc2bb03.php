<footer class="p-0 bg-dark text-white" style="line-height: 55px;">
    <div class="container small">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                &copy; Copyright - <a href="<?php echo e(route('Home')); ?>" title="All BD Questions & Solutions">Wovo Test</a> - <?php echo e(date('Y')); ?>

            </div>
            <div class="col-md-6 col-sm-12 text-md-right">
                Powered By - <a href="https://wovosoft.com" target="_blank" class="text-white"
                                title="Software Development Company">WovoSoft</a>
            </div>
        </div>
    </div>
</footer>
<style>
    .back_to_top {
        position: fixed;
        bottom: 80px;
        right: 40px;
        z-index: 9999;
        width: 30px;
        height: 30px;
        text-align: center;
        line-height: 30px;
        background: #f5f5f5;
        color: #444 !important;
        cursor: pointer;
        border-radius: 2px;
        display: none;
    }

    .back_to_top:hover {
        background: #e9ebec;
    }

    .back_to_top-show {
        display: block;
    }
</style>
<a class="back_to_top" title="Go to Top">&uarr;</a>
<script>
    //credit : https://codepen.io/alexandr-kazakov/pen/yMRPOR
    (function () {
        'use strict';

        function trackScroll() {
            var scrolled = window.pageYOffset;
            var coords = document.documentElement.clientHeight;

            if (scrolled > coords) {
                goTopBtn.classList.add('back_to_top-show');
            }
            if (scrolled < coords) {
                goTopBtn.classList.remove('back_to_top-show');
            }
        }

        function backToTop() {
            if (window.pageYOffset > 0) {
                window.scrollBy(0, -30);
                setTimeout(backToTop, 0);
            }
        }

        var goTopBtn = document.querySelector('.back_to_top');

        window.addEventListener('scroll', trackScroll);
        goTopBtn.addEventListener('click', backToTop);
    })();
    /* end begin Back to Top button  */
</script>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/layouts/footer.blade.php ENDPATH**/ ?>