<?php $__env->startSection("seo"); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center" style="margin-top: 55px">
        <h2>Blog</h2>
    </div>

     <?php if (isset($component)) { $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Container::class, []); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'my-5']); ?>
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-3']); ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, ['md' => '6']); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'pb-4']); ?>
                     <?php if (isset($component)) { $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Card::class, ['bodyClass' => 'text-justify','imgSrc' => $post->thumbnail]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'h-100']); ?>
                         <?php $__env->slot('title'); ?> 
                            <a href="<?php echo e(route('Blog.Post',$post->only('id','slug'))); ?>"><?php echo e($post->title); ?></a>
                         <?php $__env->endSlot(); ?>
                         <?php if (isset($component)) { $__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardText::class, []); ?>
<?php $component->withName('card-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php echo e(\Illuminate\Support\Str::limit(strip_tags($post->content),200,'...')); ?>

                         <?php if (isset($__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986)): ?>
<?php $component = $__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986; ?>
<?php unset($__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\CardText::class, []); ?>
<?php $component->withName('card-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-4 text-muted font-italic small']); ?>
                            Posted by <strong><?php echo e($post->author->name); ?></strong>
                            on <?php echo e(\Carbon\Carbon::parse($post->updated_at)->diffForHumans()); ?>

                         <?php if (isset($__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986)): ?>
<?php $component = $__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986; ?>
<?php unset($__componentOriginalc93e35fbb0e07c78b43fbb34c071c6f85121d986); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704)): ?>
<?php $component = $__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704; ?>
<?php unset($__componentOriginal808d5b29ba445cb2127da7cd9098baa897770704); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                 <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($component)) { $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Row::class, []); ?>
<?php $component->withName('row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($component)) { $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2 = $component; } ?>
<?php $component = $__env->getContainer()->make(Wovosoft\LaravelBootstrap\View\Components\Col::class, []); ?>
<?php $component->withName('col'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php echo e($posts->links()); ?>

             <?php if (isset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2)): ?>
<?php $component = $__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2; ?>
<?php unset($__componentOriginal74d8a98bef28b3087e6e7862c523b0ea8612e7b2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b)): ?>
<?php $component = $__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b; ?>
<?php unset($__componentOriginal87b730532e64d531e7e7b5d86d282b9b8a14889b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c)): ?>
<?php $component = $__componentOriginal6a44da809816611637fdf8c130cdeb312386915c; ?>
<?php unset($__componentOriginal6a44da809816611637fdf8c130cdeb312386915c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/blog/posts.blade.php ENDPATH**/ ?>