<div class="be-comment-block">
    <h4 class="text-muted">Comments (<?php echo e($comments->total()); ?>)</h4>
    <?php $__currentLoopData = $comments->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="be-comment">
            <div class="be-img-comment">
                <a href="blog-detail-2.html">
                    <i class="fa fa-user fa-2x"></i>
                    
                </a>
            </div>
            <div class="be-comment-content">
                <span class="be-comment-name"><?php echo e($comment->user->name); ?></span>
                <span class="be-comment-time">
                    <?php echo e(\Carbon\Carbon::parse($comment->created_at)->diffForHumans()); ?>

				</span>

                <p class="be-comment-text"><?php echo $comment->content; ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($comments->links()); ?>

</div>

<style>
    .be-comment-block {
        border: 1px solid #edeff2;
        border-radius: 2px;
        border: 1px solid #ffffff;
    }

    .comments-title {
        font-size: 16px;
        color: #262626;
        margin-bottom: 15px;
        font-family: 'Conv_helveticaneuecyr-bold';
    }

    .be-img-comment {
        width: 60px;
        height: 60px;
        float: left;
        margin-bottom: 15px;
    }

    .be-ava-comment {
        width: 60px;
        height: 60px;
        border-radius: 50%;
    }

    .be-comment-content {
        margin-left: 80px;
    }

    .be-comment-content span {
        display: inline-block;
        width: 49%;
        margin-bottom: 15px;
    }

    .be-comment-name {
        font-size: 13px;
        font-family: 'Conv_helveticaneuecyr-bold';
    }

    .be-comment-content a {
        color: #383b43;
    }

    .be-comment-content span {
        display: inline-block;
        width: 49%;
        margin-bottom: 15px;
    }

    .be-comment-time {
        text-align: right;
    }

    .be-comment-time {
        font-size: 11px;
        color: #b4b7c1;
    }

    .be-comment-text {
        font-size: 13px;
        line-height: 18px;
        color: #7a8192;
        display: block;
        background: #f6f6f7;
        border: 1px solid #edeff2;
        padding: 15px 20px 20px 20px;
    }
</style>
<?php /**PATH /home/narayan/Sites/questionbook/resources/views/components/blog/comments.blade.php ENDPATH**/ ?>