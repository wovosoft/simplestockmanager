<?php $__env->startSection('seo'); ?>
    <?php echo SEO::generate(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="jumbotron" style="margin-top: 55px;">
        <div class="container">
            <h1 class="text-center font-weight-bold">
                BCS, Bank, NTRCA, PSC and all other Questions & Solutions in One Place
            </h1>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body">
                        <h3 class="card-title">
                            <?php echo e(\App\Models\McqQuestions::count()); ?>

                        </h3>
                        Questions
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('Questions.Forum')); ?>">Find out more...</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body">
                        <h3 class="card-title">
                            <?php echo e(\App\Models\QuestionPapers::count()); ?>

                        </h3>
                        Question Papers
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('Questions.Papers')); ?>">Find out more...</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body">
                        <h3 class="card-title">
                            <?php echo e(\App\Models\Blog\Post::count()); ?>

                        </h3>
                        Blog Posts
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('Blog.Posts')); ?>">Find out more...</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body">
                        <h3 class="card-title">
                            <?php echo e(\App\Models\Courses::count()); ?>

                        </h3>
                        Courses
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('Courses')); ?>">Find out more...</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section my-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <h4>Latest Courses</h4>
                    <?php $__currentLoopData = \App\Models\Courses::query()->latest()->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row bg-light mb-1">
                            <div class="col-3">
                                <img src="<?php echo e(asset('stprage/'.$course->thumbnail)); ?>" alt="<?php echo e($course->title); ?>"
                                     class="img-fluid"/>
                            </div>
                            <div class="col">
                                <a href="<?php echo e(route('Courses.View',$course->only('id','slug'))); ?>">
                                    <?php echo e($course->title); ?>

                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-6 col-sm-12">
                    <h4>Latest Question Papers</h4>
                    <?php $__currentLoopData = \App\Models\QuestionPapers::query()->latest()->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row bg-light mb-1">
                            <div class="col-3">
                                <img src="<?php echo e(asset('storage/'.$paper->thumbnail)); ?>" alt="<?php echo e($paper->title); ?>"
                                     class="img-fluid"/>
                            </div>
                            <div class="col">
                                <a href="<?php echo e(route('Questions.Papers.View',$paper->only('id','slug'))); ?>">
                                    <?php echo e($paper->title); ?>

                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-light py-5">
        <h2 class="text-center">Our Purpose</h2>
        <div class="container">
            <div class="col-md-12 text-center">
                <p>
                    You may wonder already there are lots of job solution related websites in web,
                    then why there is another website for the same purpose???
                </p>
                <p>
                    Well, we have analysed a lot on this topic, and finally we didn't find any well organized website
                    for this purpose, hence we created this website. We are investing our best efforts to make it user
                    friendly as much possible.
                </p>
                <p>
                    Here, you can prepare yourself, test yourself, and possibly in future you may get jobs too.
                </p>
            </div>
        </div>
    </div>

    <div class="py-5">
        <h2 class="text-center">Features & Services</h2>
        <div class="container">
            <div class="row">
                <div class="col-md-4 mt-5">
                    <div class="card h-100">
                        <div class="card-body text-center h-100">
                            <h3 class="card-title">
                                Job Solution
                            </h3>
                            <p class="card-text">
                                Here you will get almost all kind of questions in Bangaldesh
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-5">
                    <div class="card h-100">
                        <div class="card-body text-center h-100">
                            <h3 class="card-title">
                                Job Circulars
                            </h3>
                            <p class="card-text">
                                Here you can find all the current and upcoming job circular information.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-5">
                    <div class="card h-100">
                        <div class="card-body text-center h-100">
                            <h3 class="card-title">
                                Online Examination
                            </h3>
                            <p class="card-text">
                                To test your skill you can participate in our online examinations.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-5">
                    <div class="card h-100">
                        <div class="card-body text-center h-100">
                            <h3 class="card-title">
                                Blog
                            </h3>
                            <p class="card-text">
                                Our hard working team gradually collects most recent information and publish here to
                                keep you updated.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-5">
                    <div class="card h-100">
                        <div class="card-body text-center h-100">
                            <h3 class="card-title">
                                Online Courses
                            </h3>
                            <p class="card-text">
                                We have awesome courses available here & most of these are FREE. You can enroll yourself
                                anytime.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-5">
                    <div class="card h-100">
                        <div class="card-body text-center h-100">
                            <h3 class="card-title">
                                Bibliography
                            </h3>
                            <p class="card-text">
                                Very often you may need to know about the different persons Bibliography. You can get
                                these information from here.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-light py-5">
        <h2 class="text-center">Join Our Newsletter</h2>
        <p class="text-center text-muted">
            To Get up-to-date information please subscribe to your newsletter
        </p>
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <form action="#" class="form">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <div class="input-group">
                                <input required type="email" class="form-control" placeholder="Your Email Address">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary">Subscribe</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narayan/Sites/questionbook/resources/views/pages/home.blade.php ENDPATH**/ ?>